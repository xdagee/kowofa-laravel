@extends('layouts.app')

@section('content')

    <div class="section-6">
        <div class="styleguide-block">
            <div class="div-block-77">
                <h1 class="heading-38">My Works. ⚒</h1>
            </div>
        </div>
    </div>

@endsection